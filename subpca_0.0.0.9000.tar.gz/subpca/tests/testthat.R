library(testthat)
library(subpca)

test_check("subpca")
