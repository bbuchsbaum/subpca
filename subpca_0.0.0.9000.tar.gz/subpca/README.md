
<!-- README.md is generated from README.Rmd. Please edit that file -->

# subpca

<!-- badges: start -->
<!-- badges: end -->

The goal of subpca is to provide a way of computing pca within
sub-blocks and then a second (“metapca”) over each cluster-wise pca.

## Installation

You can install the development version from
[GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("bbuchsbaum/subpca")
```
